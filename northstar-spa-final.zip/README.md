# Northstar — Weekend Getaway SPA

## Project overview

Northstar is a small single-page application (SPA) for discovering weekend getaways. I built it to practise connecting HTML, CSS, and JavaScript into one working interface: users can explore places, filter results, open a detail page, and save favourites without a full page reload.

The project is deliberately dependency-free. Its destination data and original SVG illustrations are included locally, which makes the demo easy to inspect and run.

## Run it

**Requirements:** Node.js 18 or newer. There are no third-party runtime dependencies.

```text
npm start
```

Open <http://127.0.0.1:4173> in a browser. Keep the terminal running while you use the application. The bundled `server.js` serves the project locally. To use a different port in PowerShell, run `$env:PORT = 5000; npm start`, then open <http://127.0.0.1:5000>.

The app can also be hosted as static files at the site root. Query-string routes avoid needing server-side route rewrites.

## Quick walkthrough

1. Choose **Explore getaways**, search for `coast`, and submit. The URL changes to `?page=explore&q=coast&category=All`, and the result list updates without a full reload.
2. Open **Salt House**, then use browser Back and Forward to check history navigation.
3. Select the heart, open **Saved**, and refresh. The saved place is restored from browser storage.
4. Search for `Antarctica` to see the empty state, or open `?page=destination&id=not-a-place` to see the not-found page.
5. Use the keyboard to navigate the links and controls. Resize the browser to see the responsive layout.

## Project map

```text
northstar-spa/
├── index.html               Accessible SPA shell and shared chrome
├── styles.css               Responsive design, transitions, reduced-motion rules
├── app.js                   Sample data, query router, views, search, saved state
├── server.js                Dependency-free local static-file server
├── package.json             Start command
├── README.md                Setup and quick-start examples
├── technical-report.md      Architecture, decisions, challenges, test plan
└── assets/                  Locally bundled SVG illustrations and favicon
```

All destination descriptions and prices are illustrative demo data. There is no booking backend, payment processing, account system, or external image request.

## Submission notes

The technical report explains the route design, state management, implementation challenges, and validation checklist. The inline code comments are kept brief and focus on the less-obvious decisions, such as URL routing and event delegation.

# Northstar SPA — Technical Report

**Project type:** Front-end internship task  
**Technologies:** HTML, CSS, JavaScript, Node.js (local development server)  
**Application:** Northstar weekend getaway finder

## Summary

For this project, I built a small SPA that lets a visitor browse weekend getaways without loading a new document for each page. The main learning goal was to connect the URL, browser history, rendered content, and saved-item state so that they behave as one application. I kept the project framework-free so the routing and DOM updates are visible in the source code.

## 1. Project plan

**Objective.** Build a small but complete single-page travel-discovery application that demonstrates dynamic rendering, client-side routes, browser history, durable state, useful empty/error states, and a polished responsive interface.

**Audience and concept.** Northstar is a friendly directory of nearby weekend escapes. The tone and compact destination listings keep the example concrete: users can explore stays, search and filter the directory, read a detail, and save places for later.

**Implementation sequence.**

1. Define a semantic HTML shell with shared navigation, main content, footer, live announcements, and a keyboard skip link.
2. Create one source of truth for sample destination records and reusable, escaped card rendering.
3. Add a query-string router backed by `history.pushState` and `popstate` so the URL, rendered view, and browser controls remain in sync.
4. Implement search/filter state in route parameters and saved trips in `localStorage`.
5. Style each view responsively, add restrained transitions, and honor reduced-motion preferences.
6. Exercise direct links, refresh, search, save/unsave, history navigation, no-results, and invalid routes.

## 2. Architecture

| File | Responsibility |
| --- | --- |
| `index.html` | Persistent application shell, landmarks, accessible live regions, and CSS/JS entry points. |
| `styles.css` | Design tokens, layout and card styles, responsive breakpoints, focus states, motion, reduced-motion support. |
| `app.js` | Sample data, URL parsing/building, page rendering, navigation interception, form handling, saved-trip state, and user feedback. |
| `server.js` | Optional zero-dependency local static server for a reliable HTTP origin during development. |
| `assets/*.svg` | Hand-authored, locally bundled illustrations; no image API or network is needed. |

The app uses a lightweight render-on-navigation pattern rather than a framework. The persistent shell stays mounted; the `#app` region is regenerated from the current route and in-memory state. One delegated click handler handles internal links and save buttons, and one submit handler handles the search form. This keeps event wiring stable when the view is re-rendered. Brief comments in the source call out these key decisions without restating each line of code.

### Route table

| URL | View | Route data |
| --- | --- | --- |
| `/?page=home` | Home and featured stays | None |
| `/?page=explore` | Searchable/filterable directory | `q`, `category` |
| `/?page=destination&id=cedar-house` | Destination detail | `id` |
| `/?page=saved` | Saved-trip shortlist | Saved IDs in local storage |
| `/?page=about` | Project/story page | None |
| Any unknown page or destination ID | Friendly not-found view | Invalid route |

The default route is home. Query parameters are parsed with `URLSearchParams`; generated internal links use the same route builder. `pushState` changes the address and appends a history entry without reloading, while the `popstate` listener redraws the correct view on browser Back and Forward. Search terms and category selection are URLs, not hidden transient state, so they survive refresh and can be shared.

### State model

- **Navigation and filters:** encoded in `window.location.search`; the URL is the source of truth.
- **Saved stays:** a set of valid destination IDs, hydrated from `localStorage` and written back after each change.
- **View markup:** derived from the current route and state; it is not separately persisted.
- **Transient feedback:** announced in a shared status region and dismissed automatically.

Malformed stored data is reported to the console and falls back to an empty shortlist for the current visit. Storage write failures are also reported and explained to the user; the current-session shortlist continues to work in memory.

## 3. Design decisions and rationale

- **Query-string routes instead of nested paths:** each screen can be refreshed or opened directly on a basic static host without special rewrite configuration. Example: `/?page=destination&id=salt-house`.
- **No framework or dependency install:** this small demo stays easy to inspect and run. The reusable data-driven templates provide structure without unnecessary setup.
- **Local SVG artwork:** original illustrations make the ZIP self-contained, quick to load, and usable offline. There are no external image or font requests required by the app; system font fallbacks keep typography available offline.
- **One destination data list:** home, explore, detail, and saved views share the same six sample records, reducing inconsistencies.
- **Native links and forms:** anchors have real URLs, the search form is keyboard-submittable, and modified clicks retain normal browser behavior.
- **Accessible interaction:** semantic navigation/main/footer landmarks, skip link, visible focus, button labels and pressed state, descriptive image text, live result/status regions, and reduced-motion handling.
- **Responsive layout:** cards and details adapt from three columns to two and then one; mobile navigation and forms reflow for small screens.

## 4. Implementation challenges and approaches

### Keeping URL and UI state synchronized

Changing markup alone would leave stale URLs and make Back/Forward unreliable. Every internal route is represented in the query string, navigation uses `pushState`, and `popstate` re-renders from the current URL. Search and filters are serialized into the route, so the same view returns after refresh.

### Safe, reliable rendering

Destination records are interpolated into HTML templates. A small HTML-escaping helper protects all user-controlled or data-derived text and attributes before insertion. Search terms are compared as text and are never treated as HTML. Invalid IDs and unknown routes intentionally resolve to a visible not-found screen.

### Persistence without a backend

This demo has no account or database, so saved IDs are stored locally in the visitor’s browser. The app validates stored data against the known destination list. Read/write failures are not silently mistaken for successful persistence: the console records the error and the UI explains the session-only behavior.

### Reliable local execution

The History API requires a same-origin browsing context; opening the HTML directly from disk is not a dependable development setup. The included dependency-free `server.js` supplies that context and a single `npm start` command. Since routes only change the query string, static hosting does not need an SPA rewrite rule.

### Motion and user preferences

Page and card transitions are deliberately short and subtle. A `prefers-reduced-motion` media query suppresses nonessential motion for visitors who have requested less animation.

## 5. Examples and expected behavior

**Search flow**

1. Visit `/?page=explore`.
2. Enter `coast` and submit.
3. The app navigates to `/?page=explore&q=coast&category=All` without reloading, displays Salt House, and announces the result count.
4. Refresh: the same search and filtered result return.

**History flow**

1. Open Explore, then open Cedar House.
2. Select browser Back: the Explore route and its prior URL return.
3. Select Forward: the Cedar House detail returns.

**Saved-place flow**

1. Save Juniper Camp from a card or its detail page.
2. The heart state and header count update; the saved page shows the place.
3. Refresh: the saved shortlist is restored from local storage.
4. Remove the place: it disappears from Saved and the count decreases.

**Error/empty flows**

- `/?page=destination&id=missing-place` displays the not-found view.
- Search `Antarctica` displays a no-results message and a clear-filters action.
- An unavailable or denied local-storage write displays a message instead of claiming that the save persisted.

## 6. Validation checklist

| Check | Expected result |
| --- | --- |
| Load home | Header, featured cards, and footer render with no page reload. |
| Internal navigation | Address changes; browser document does not reload. |
| Back and Forward | Correct view is restored from the URL. |
| Search and category filter | Result count/list reflect filters; query survives refresh. |
| Save, remove, refresh | Button/count/list update and valid saved IDs persist. |
| Empty search and invalid detail | Helpful empty/not-found screens appear. |
| Narrow viewport | Layout reflows without horizontal overflow. |
| Keyboard navigation | Skip link, navigation, search, cards, and actions are reachable and visibly focused. |
| Reduced motion | Nonessential page/card motion is minimized. |
| Offline assets | Illustrations load from the project’s own `assets/` folder. |

### Final verification performed

I checked both JavaScript files with Node’s syntax checker and confirmed that the local server returned successful responses for the home page, a query-string route, and a bundled SVG asset. In the browser, I exercised Explore, a filtered search, a destination detail, Back navigation, saving and removing a stay, the saved list, and the no-results and unknown-destination screens. I also checked that saved state returned after a page refresh. The ZIP archive was checked to include the app files, report, and all bundled illustrations.

## 7. Scope and limitations

This is a frontend simulation, not a booking service: prices, ratings, availability, traveler counts, and destination descriptions are illustrative. There is no live inventory, search API, login, payment flow, server-side persistence, or actual reservation action. Saved trips are scoped to one browser profile/device and are not synchronized across devices. A real product would replace the sample array and local storage with validated API responses, add loading/retry states and authentication as needed, and include end-to-end tests against the production host.

## 8. Delivery contents

The ZIP archive contains the complete runnable project: the HTML shell, CSS, JavaScript, package manifest, local server, README, this report, and all local SVG assets. No `node_modules`, build output, or external services are required.

## 9. Internship reflection

The main challenge was making navigation feel like a normal website while still avoiding full page reloads. I learned that updating the visible content is only part of routing: the URL and browser history also need to stay in sync. Storing the search term in the URL made the results refreshable and shareable, while handling the `popstate` event made Back and Forward work as expected.

I also learned to plan for failure states early. Browser storage can be unavailable, a search can have no matches, and a user can open an invalid destination link. Showing a clear message for each case made the demo feel more complete than only testing its happy path.

If I continued this project, I would connect it to a real destination API, add automated browser tests, and replace local-only saved trips with account-backed storage. Prices and destination details in this version are sample content, not live booking information.
